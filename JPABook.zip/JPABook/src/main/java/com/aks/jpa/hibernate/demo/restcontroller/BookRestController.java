package com.aks.jpa.hibernate.demo.restcontroller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aks.jpa.hibernate.demo.entity.Book;
import com.aks.jpa.hibernate.demo.exception.ResourceNotFoundException;
import com.aks.jpa.hibernate.demo.repository.BookRepository;

@CrossOrigin(origins = "https://localhost:4200")
@RestController
@RequestMapping("/api")
public class BookRestController {

	@Autowired
	private BookRepository bookRepository;
	
	// All Books
	@GetMapping("/books")
	public List<Book> getAllEmployees(){
		return (List<Book>) bookRepository.findAll();
	}		
	
	// Book Rest API
	@PostMapping("/books")
	public Book createEmployee(@RequestBody Book book) {
		return bookRepository.save(book);
	}
	
	// get Book by BookId RestAPI
	@GetMapping("/books/{bookid}")
	public ResponseEntity<Book> getBookByBookId(@PathVariable Long bookid) {
		Book book = bookRepository.findById(bookid)
				.orElseThrow(() -> new ResourceNotFoundException("Book Does Not Exist With BookId :" + bookid));
		return ResponseEntity.ok(book);
	}
	
	// Update Book RestAPI
	@PutMapping("/books/{bookid}")
	public ResponseEntity<Book> updateBook(@PathVariable Long bookid, @RequestBody Book bookDetails){
		Book book = bookRepository.findById(bookid)
				.orElseThrow(() -> new ResourceNotFoundException("Book Does Not Exist With BookId :" + bookid));
		
		book.setBookid(bookDetails.getBookid());
		book.setBookname(bookDetails.getBookname());
		book.setBookauthor(bookDetails.getBookauthor());
		
		Book updatedBook = bookRepository.save(book);
		return ResponseEntity.ok(updatedBook);
	}
	
	// Delete Book RestAPI
	@DeleteMapping("/books/{bookid}")
	public ResponseEntity<Map<String, Boolean>> deleteBook(@PathVariable Long bookid){
		Book book= bookRepository.findById(bookid)
				.orElseThrow(() -> new ResourceNotFoundException("Book Does Not Exist With BookId :" + bookid));
		
		bookRepository.delete(book);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	
}
